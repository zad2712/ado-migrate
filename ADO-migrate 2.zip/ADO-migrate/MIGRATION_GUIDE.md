# ADO → GitHub Actions Migration Runbook

A step-by-step guide for a DevOps engineer to migrate every Azure DevOps pipeline and classic release in a project to GitHub Actions, using the agent in this repo.

> **Estimated time:** 1–2 hours of setup + ~5 min of agent runtime per definition + manual review/test time per workflow.

> **Platforms:** macOS, Linux, and Windows are all supported. Where commands differ, both forms are shown — pick the row that matches your shell.

---

## Phase 0 — Prerequisites

Before starting, confirm you have:

| Requirement | How to verify (macOS/Linux) | How to verify (Windows) |
|---|---|---|
| Python 3.10+ | `python3 --version` | `py -3 --version` |
| `pip` | `python3 -m pip --version` | `py -3 -m pip --version` |
| Anthropic API key | https://console.anthropic.com → API Keys | same |
| ADO PAT with **Build (Read)** + **Release (Read)** | https://dev.azure.com/<org>/_usersSettings/tokens | same |
| Read access to the target ADO project | Open the project in the ADO UI | same |
| Write access to the destination GitHub repo(s) | You can push to `.github/workflows/` | same |

If any is missing, stop and obtain it before proceeding.

> **Windows note:** Install Python 3.10+ from https://www.python.org/downloads/ and check **"Add Python to PATH"** during install. The `py` launcher comes with that installer. Microsoft Store Python also works but tends to have stricter file-permission rules — the python.org installer is recommended.

---

## Phase 1 — Set up the migration tool (one-time)

### 1.1 Clone / open this repo

```bash
cd ~/GitHub/code/ADO-migrate
```

### 1.2 Create a virtualenv and install deps

**macOS / Linux**

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

**Windows (PowerShell)**

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

If PowerShell blocks the activation script with an "execution policy" error, run this once and retry:

```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

**Windows (CMD)**

```cmd
py -3 -m venv .venv
.venv\Scripts\activate.bat
pip install -r requirements.txt
```

### 1.3 Configure environment variables

**macOS / Linux**

```bash
cp .env.example .env
```

**Windows (PowerShell)**

```powershell
Copy-Item .env.example .env
```

**Windows (CMD)**

```cmd
copy .env.example .env
```

Edit `.env` in your editor of choice (VS Code, Notepad++, vim, …):

```ini
ANTHROPIC_API_KEY=sk-ant-...
ADO_ORG_URL=https://dev.azure.com/<your-org>
ADO_PROJECT=<your-project>          # URL-encode spaces if any
ADO_PAT=<paste your PAT here>
```

> **Security:** `.env` is gitignored. Never commit it. Rotate the PAT when migration is done.

### 1.4 Smoke-test the connection

The `python` command is identical on every platform once the venv is active:

```bash
python -m ado_migrate.cli list --kind pipelines
python -m ado_migrate.cli list --kind releases
```

You should see JSON arrays of pipelines and releases. If you get `401`, the PAT is wrong or expired. If you get `404`, the org URL or project name is wrong.

---

## Phase 2 — Inventory and prioritize

### 2.1 Capture an inventory

```bash
python -m ado_migrate.cli list --kind all > inventory.json
```

Open `inventory.json` and skim the names. Group them mentally into:

- **Tier 1 (critical):** production deploys, scheduled jobs that gate releases
- **Tier 2 (important):** staging deploys, nightly tests
- **Tier 3 (nice-to-have):** ad-hoc utilities, deprecated pipelines

### 2.2 Decide what NOT to migrate

For each definition, ask:

- Is it still in use? (Check the last successful run in ADO UI — if it hasn't run in 6+ months, consider archiving instead.)
- Does it duplicate another pipeline?
- Is it an experiment that was never cleaned up?

Mark these as **skip** in your inventory. Migrating dead pipelines wastes review time.

### 2.3 Pick a pilot

Choose **one Tier-3 definition** as your pilot. You want something low-risk to validate the agent's output and sharpen your review eye before touching production.

---

## Phase 3 — Pilot migration

### 3.1 Run the agent on the pilot

For a YAML/build pipeline:

```bash
python -m ado_migrate.cli migrate --pipeline-id <id>
```

For a classic release:

```bash
python -m ado_migrate.cli migrate --release-id <id>
```

The agent will:

1. Fetch the ADO definition via REST.
2. Convert it to a GitHub Actions workflow.
3. Write it to `output/.github/workflows/<slug>.yml`.

You'll see a token usage line at the end (`[stop=end_turn in=… out=…]`). A 50-stage classic release typically uses 30–80k input + 5–15k output tokens.

### 3.2 Review the generated YAML

Open `output/.github/workflows/<slug>.yml` and check:

- [ ] **Triggers** — does `on:` match the original ADO trigger? (Push branches, PR branches, cron, manual.)
- [ ] **Runners** — `runs-on:` matches the original agent pool. Self-hosted? Make sure the runner label is correct.
- [ ] **Job order** — `needs:` reflects the original stage/environment dependsOn order.
- [ ] **Steps** — every ADO task is represented. Look for `# TODO` comments where the agent couldn't cleanly map a task.
- [ ] **Secrets** — every `${{ secrets.NAME }}` reference has a corresponding entry you'll need to add to GitHub repo/org/environment secrets.
- [ ] **Variable groups** — listed in a comment; you'll need to recreate these as GitHub Environment variables/secrets.
- [ ] **Approvals** — pre-deployment approvals appear as `environment:` references; you'll configure required reviewers in GitHub Environments.
- [ ] **Service connections** — Azure/AWS/Docker logins now use OIDC or secret-based auth. The agent leaves a TODO; pick the right approach for your org.

### 3.3 Resolve TODOs

For every `# TODO` in the file, do one of:

- Replace with the correct action/secret if you know it.
- Add a follow-up note in your migration tracker if it needs research.
- Delete the step if the original was obsolete.

### 3.4 Dry-run in GitHub

1. Copy `output/.github/workflows/<slug>.yml` into your target repo's `.github/workflows/` directory **on a branch**.
2. Open a draft PR.
3. If the workflow has `on: push` or `on: pull_request`, it will run on the PR — watch the Actions tab.
4. If it's `on: workflow_dispatch` only, trigger it manually from the Actions tab once the PR is merged or from the branch.
5. Compare the run output to the most recent ADO run. Diff the artifacts, deploy targets, environment variables, and exit codes.

### 3.5 Iterate

If the workflow fails or behaves differently:

- **Don't manually fix and forget** — note the pattern. If the agent mis-mapped a common ADO task, update `prompts/system.md` so subsequent migrations get it right the first time.
- Re-run the agent on the pilot after updating the prompt to validate the fix.

Once the pilot passes a real run end-to-end, you have a green light to scale.

---

## Phase 4 — Bulk migration

### 4.1 Run the agent on all definitions

```bash
python -m ado_migrate.cli migrate --all 2>&1 | tee migration.log
```

This iterates every pipeline and release in the project. Expect roughly **2–8 minutes per definition** depending on size. A project with 50 definitions will take 2–6 hours of agent time. You can leave it running.

> **Cost note:** Opus 4.7 is ~$5/1M input, ~$25/1M output. A typical migration run is $0.50–$2 per definition. Budget $25–100 for a 50-definition project.

### 4.2 Triage the output

**macOS / Linux**

```bash
ls output/.github/workflows/
grep -l "TODO" output/.github/workflows/*.yml | wc -l
```

**Windows (PowerShell)**

```powershell
Get-ChildItem output\.github\workflows
(Select-String -Path output\.github\workflows\*.yml -Pattern "TODO" -List).Count
```

Sort generated workflows into three buckets based on TODO count and complexity:

| Bucket | Criteria | Action |
|---|---|---|
| **Clean** | 0 TODOs, simple structure | Quick review, ship |
| **Needs work** | 1–5 TODOs, mostly mechanical | Fix manually, ship |
| **Complex** | 6+ TODOs or self-hosted/custom-task heavy | Schedule a focused review session |

### 4.3 Set up shared GitHub infrastructure

Before opening per-workflow PRs, do the org/repo setup once:

- **GitHub Environments** — create one per ADO release stage (Dev, Staging, Prod). Set required reviewers on Prod.
- **Secrets** — add every secret referenced across the workflows at the appropriate scope (org / repo / environment).
- **OIDC / cloud auth** — if migrating from Azure service connections, configure [federated credentials](https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-azure) once at the org level.
- **Self-hosted runners** — if any workflows need them, register and label them.
- **Variable groups** — recreate as GitHub Environment variables.

### 4.4 Roll out by tier

Open PRs in this order. **Do not bulk-merge.**

1. **Tier 3 first** — low-risk workflows. Get muscle memory for the review process.
2. **Tier 2** — staging/test workflows. Verify they catch the same regressions ADO did by running a known-bad commit through both.
3. **Tier 1 last** — production deploys. For these, **run ADO and GHA in parallel for at least one full release cycle** before disabling the ADO release. Compare outputs at every stage.

Per-workflow PR checklist:

- [ ] All TODOs resolved
- [ ] All secrets exist in GitHub
- [ ] Environment(s) created with correct reviewers
- [ ] Workflow has run at least once successfully on a non-prod target
- [ ] Original ADO definition is **disabled** (not deleted) once the GHA version has shipped one real release

---

## Phase 5 — Cutover and decommission

For each migrated workflow:

1. Disable the ADO trigger (in ADO UI: Pipeline → Triggers → uncheck CI/CD; or Release → Triggers → Disable).
2. Add a note in the ADO definition description: `Migrated to GHA: <repo>/.github/workflows/<file>. Disabled YYYY-MM-DD.`
3. Wait two weeks of clean GHA runs.
4. Delete the ADO definition (or leave disabled if your org keeps audit history).

When all definitions are migrated:

- Revoke the migration PAT.
- Remove `.env` from your local machine (or rotate the Anthropic key).
- Archive this `ADO-migrate` repo or delete the local clone.

---

## Troubleshooting

**Agent writes a workflow with mostly `# TODO` blocks.**
The original definition has many custom or marketplace ADO tasks the agent doesn't know. Either expand `prompts/system.md` with mappings for those tasks, or treat the file as a starter scaffold and fill it in manually.

**`401 Unauthorized` from the ADO REST API.**
PAT expired or missing the right scope. Generate a new one with **Build (Read)** + **Release (Read)**.

**`429 Too Many Requests` from Anthropic during `--all`.**
Add a sleep between definitions, or run in batches. The CLI calls definitions sequentially so this is rare unless your tier is low.

**Generated YAML fails `yaml.safe_load`.**
The writer rejects this and raises. Re-run the agent — the model occasionally produces broken YAML and retrying fixes it. If it persists, lower `effort` to `medium` (some long outputs are more robust at lower effort).

**Workflow runs in GHA but fails because a secret is missing.**
Expected for the first run. Add the secret in GitHub repo/environment settings and re-run. Capture every missing secret across runs into a single tracker so you can populate them in batches.

**Two ADO stages mapped to one GHA job.**
The agent collapsed them. If you need them as separate GHA jobs (e.g., for distinct environments or approvals), edit the YAML manually and split. Update the prompt if this is a repeating pattern.

**A self-hosted runner pool isn't represented correctly.**
The agent emits `runs-on: self-hosted` with a `# TODO` for the label. Replace with your actual label set (e.g., `[self-hosted, linux, prod]`).

### Windows-specific

**`Activate.ps1 cannot be loaded because running scripts is disabled on this system.`**
PowerShell execution policy. Run once: `Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned`, then re-activate.

**`'python3' is not recognized as an internal or external command.`**
Use `py -3` instead, or use the unqualified `python` once the venv is active. The `py` launcher ships with the python.org installer.

**`UnicodeDecodeError` when reading `.env` or a JSON export.**
Re-save the file as UTF-8 (no BOM). VS Code: bottom-right encoding indicator → "Save with Encoding" → "UTF-8". Notepad: "Save As" → Encoding "UTF-8".

**`PermissionError: [Errno 13]` when writing to `output\`.**
Close any editor or Explorer preview pane that has the file open, then re-run. OneDrive-synced folders sometimes lock files briefly during sync.

**Long path errors (`The filename or extension is too long`).**
Enable long-path support: in an admin PowerShell, run `New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem" -Name "LongPathsEnabled" -Value 1 -PropertyType DWORD -Force` and reboot. Alternatively, clone this repo to a short path like `C:\dev\ADO-migrate`.

**Generated YAML has CRLF line endings and GHA complains.**
The writer forces `\n` on every platform, so this shouldn't happen. If it does, check that your editor isn't re-saving with CRLF. In VS Code, click "CRLF" in the bottom-right and switch to "LF".

---

## Reference

- [GitHub Actions docs](https://docs.github.com/en/actions)
- [Azure DevOps REST API — Pipelines](https://learn.microsoft.com/en-us/rest/api/azure/devops/pipelines)
- [Azure DevOps REST API — Release](https://learn.microsoft.com/en-us/rest/api/azure/devops/release)
- [GitHub OIDC with Azure](https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-azure)
- Conversion rules and task mappings: see `prompts/system.md` in this repo.
