"""Azure DevOps REST API client with local-file fallback.

The agent calls these as tools. Each function returns plain JSON-serializable
data so it round-trips cleanly through tool-use turns.
"""

from __future__ import annotations

import json
import os
from base64 import b64encode
from pathlib import Path
from typing import Any

import requests

ADO_API_VERSION_PIPELINES = "7.1"
ADO_API_VERSION_RELEASES = "7.1"


def _auth_header() -> dict[str, str]:
    pat = os.environ.get("ADO_PAT", "")
    if not pat:
        raise RuntimeError("ADO_PAT not set in environment")
    token = b64encode(f":{pat}".encode()).decode()
    return {"Authorization": f"Basic {token}", "Accept": "application/json"}


def _org_url() -> str:
    url = os.environ.get("ADO_ORG_URL", "").rstrip("/")
    if not url:
        raise RuntimeError("ADO_ORG_URL not set in environment")
    return url


def _project() -> str:
    proj = os.environ.get("ADO_PROJECT", "")
    if not proj:
        raise RuntimeError("ADO_PROJECT not set in environment")
    return proj


def list_pipelines() -> list[dict[str, Any]]:
    """List YAML/build pipelines (the modern ADO Pipelines surface)."""
    url = f"{_org_url()}/{_project()}/_apis/pipelines"
    r = requests.get(
        url,
        headers=_auth_header(),
        params={"api-version": ADO_API_VERSION_PIPELINES},
        timeout=30,
    )
    r.raise_for_status()
    data = r.json().get("value", [])
    return [
        {"id": p["id"], "name": p["name"], "folder": p.get("folder", "\\")}
        for p in data
    ]


def list_releases() -> list[dict[str, Any]]:
    """List classic Release definitions (the UI-built CD surface)."""
    org_host = _org_url().replace("dev.azure.com", "vsrm.dev.azure.com")
    url = f"{org_host}/{_project()}/_apis/release/definitions"
    r = requests.get(
        url,
        headers=_auth_header(),
        params={"api-version": ADO_API_VERSION_RELEASES},
        timeout=30,
    )
    r.raise_for_status()
    data = r.json().get("value", [])
    return [
        {"id": d["id"], "name": d["name"], "path": d.get("path", "\\")}
        for d in data
    ]


def fetch_pipeline_definition(pipeline_id: int) -> dict[str, Any]:
    """Fetch the full definition (including YAML body if present) for a pipeline."""
    url = f"{_org_url()}/{_project()}/_apis/pipelines/{pipeline_id}"
    r = requests.get(
        url,
        headers=_auth_header(),
        params={"api-version": ADO_API_VERSION_PIPELINES},
        timeout=30,
    )
    r.raise_for_status()
    return r.json()


def fetch_release_definition(release_id: int) -> dict[str, Any]:
    """Fetch a classic release definition with all stages, tasks, and variables expanded."""
    org_host = _org_url().replace("dev.azure.com", "vsrm.dev.azure.com")
    url = f"{org_host}/{_project()}/_apis/release/definitions/{release_id}"
    r = requests.get(
        url,
        headers=_auth_header(),
        params={
            "api-version": ADO_API_VERSION_RELEASES,
            "$expand": "environments,variables,tasks",
        },
        timeout=30,
    )
    r.raise_for_status()
    return r.json()


def read_local_export(path: str) -> dict[str, Any]:
    """Read an ADO definition exported as JSON from disk (offline fallback)."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"No such file: {path}")
    return json.loads(p.read_text(encoding="utf-8"))
