"""Command-line entry point for ADO → GHA migration."""

from __future__ import annotations

import json
import sys

import click
from dotenv import load_dotenv

from . import agent
from .tools import ado_client

load_dotenv()


@click.group()
def cli() -> None:
    """Migrate Azure DevOps pipelines/releases to GitHub Actions workflows."""


@cli.command("list")
@click.option("--kind", type=click.Choice(["pipelines", "releases", "all"]), default="all")
def list_cmd(kind: str) -> None:
    """List ADO pipelines and/or release definitions."""
    if kind in ("pipelines", "all"):
        click.echo("# Pipelines")
        click.echo(json.dumps(ado_client.list_pipelines(), indent=2))
    if kind in ("releases", "all"):
        click.echo("# Releases")
        click.echo(json.dumps(ado_client.list_releases(), indent=2))


@cli.command("migrate")
@click.option("--pipeline-id", type=int, help="ADO pipeline (build) definition ID.")
@click.option("--release-id", type=int, help="ADO classic release definition ID.")
@click.option(
    "--from-file",
    type=click.Path(exists=True, dir_okay=False),
    help="Migrate from a local JSON export instead of calling the ADO API.",
)
@click.option("--all", "migrate_all", is_flag=True, help="Migrate every pipeline and release in the project.")
def migrate_cmd(
    pipeline_id: int | None,
    release_id: int | None,
    from_file: str | None,
    migrate_all: bool,
) -> None:
    """Run the agent to convert one or more ADO definitions to GHA workflows."""
    requests: list[str] = []

    if migrate_all:
        for p in ado_client.list_pipelines():
            requests.append(
                f"Migrate ADO pipeline id={p['id']} (name={p['name']!r}). "
                "Fetch the definition, convert it, and write the workflow."
            )
        for r in ado_client.list_releases():
            requests.append(
                f"Migrate ADO classic release id={r['id']} (name={r['name']!r}). "
                "Fetch the definition, convert it, and write the workflow."
            )
    elif pipeline_id is not None:
        requests.append(
            f"Migrate ADO pipeline id={pipeline_id}. "
            "Fetch the definition, convert it to a GitHub Actions workflow, and write it."
        )
    elif release_id is not None:
        requests.append(
            f"Migrate ADO classic release id={release_id}. "
            "Fetch the definition, convert it to a GitHub Actions workflow, and write it."
        )
    elif from_file:
        requests.append(
            f"Migrate the ADO definition in the local file {from_file!r}. "
            "Read it with read_local_ado_export, convert it, and write the workflow."
        )
    else:
        click.echo("Specify one of --pipeline-id, --release-id, --from-file, or --all.", err=True)
        sys.exit(2)

    for req in requests:
        click.echo(f"\n=== {req[:80]}... ===")
        result = agent.run(req)
        click.echo(result["text"])
        click.echo(
            f"[stop={result['stop_reason']} "
            f"in={result['usage']['input_tokens']} out={result['usage']['output_tokens']}]"
        )


if __name__ == "__main__":
    cli()
