"""Claude agent that converts ADO definitions into GitHub Actions YAML.

Uses the beta tool runner (`client.beta.messages.tool_runner`) so the SDK
handles the tool-use loop automatically. Tools wrap the ADO REST client and
the local YAML writer.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from anthropic import Anthropic
from anthropic.lib.tools import beta_tool

from .tools import ado_client, gha_writer

MODEL = os.environ.get("CLAUDE_MODEL", "claude-opus-4-7")
MAX_TOKENS = 32000

PROMPT_PATH = Path(__file__).resolve().parents[1] / "prompts" / "system.md"


def _system_prompt() -> str:
    return PROMPT_PATH.read_text(encoding="utf-8")


@beta_tool
def list_ado_pipelines() -> str:
    """List YAML/build pipelines in the configured ADO project. Returns id, name, folder."""
    return json.dumps(ado_client.list_pipelines())


@beta_tool
def list_ado_releases() -> str:
    """List classic release definitions in the configured ADO project. Returns id, name, path."""
    return json.dumps(ado_client.list_releases())


@beta_tool
def fetch_ado_pipeline_definition(pipeline_id: int) -> str:
    """Fetch the full ADO pipeline definition (including YAML body if available) by ID."""
    return json.dumps(ado_client.fetch_pipeline_definition(pipeline_id))


@beta_tool
def fetch_ado_release_definition(release_id: int) -> str:
    """Fetch a classic ADO release definition with environments, tasks, and variables expanded."""
    return json.dumps(ado_client.fetch_release_definition(release_id))


@beta_tool
def read_local_ado_export(path: str) -> str:
    """Read an ADO definition from a local JSON file (offline fallback). Path is relative to the repo or absolute."""
    return json.dumps(ado_client.read_local_export(path))


@beta_tool
def write_gha_workflow(name: str, yaml_content: str) -> str:
    """Write a GitHub Actions workflow YAML to output/.github/workflows/<slug>.yml.

    Args:
        name: human-readable workflow name (used to derive the filename slug).
        yaml_content: the full workflow YAML as a string.

    Returns the absolute path written.
    """
    return gha_writer.write_workflow(name, yaml_content)


TOOLS = [
    list_ado_pipelines,
    list_ado_releases,
    fetch_ado_pipeline_definition,
    fetch_ado_release_definition,
    read_local_ado_export,
    write_gha_workflow,
]


def run(user_request: str) -> dict[str, Any]:
    """Run the agent with a single user instruction. Returns the final message."""
    client = Anthropic()
    runner = client.beta.messages.tool_runner(
        model=MODEL,
        max_tokens=MAX_TOKENS,
        thinking={"type": "adaptive"},
        output_config={"effort": "high"},
        system=_system_prompt(),
        tools=TOOLS,
        messages=[{"role": "user", "content": user_request}],
    )
    final = runner.until_done()
    return {
        "stop_reason": final.stop_reason,
        "usage": {
            "input_tokens": final.usage.input_tokens,
            "output_tokens": final.usage.output_tokens,
        },
        "text": "".join(
            block.text for block in final.content if getattr(block, "type", None) == "text"
        ),
    }
