# ADO-migrate

AI agent that migrates Azure DevOps pipelines and classic releases to GitHub Actions workflows.

The agent uses the Anthropic Claude Agent SDK (Opus 4.7) to read ADO definitions — either live via the ADO REST API or from JSON/YAML exports placed in `examples/` — and writes equivalent GitHub Actions workflow YAML to `output/.github/workflows/`.

## Setup

Works on macOS, Linux, and Windows (PowerShell or CMD). Requires Python 3.10+.

**macOS / Linux**

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# fill in ANTHROPIC_API_KEY, ADO_ORG_URL, ADO_PROJECT, ADO_PAT
```

**Windows (PowerShell)**

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
# edit .env in your editor of choice
```

If activation is blocked, run once: `Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned`.

**Windows (CMD)**

```cmd
py -3 -m venv .venv
.venv\Scripts\activate.bat
pip install -r requirements.txt
copy .env.example .env
```

The PAT needs **Build (Read)** and **Release (Read)** scopes.

## Usage

List ADO pipelines (build + release definitions) in the configured project:

```bash
python -m ado_migrate.cli list
```

Migrate one pipeline by ID:

```bash
python -m ado_migrate.cli migrate --pipeline-id 42
python -m ado_migrate.cli migrate --release-id 17
```

Migrate from a local export file (no ADO API call):

```bash
python -m ado_migrate.cli migrate --from-file examples/sample-release.json
```

Migrate everything in the project:

```bash
python -m ado_migrate.cli migrate --all
```

Converted workflows land in `output/.github/workflows/<name>.yml`. Review them, then drop into the target repo's `.github/workflows/`.

## How it works

The agent (in `ado_migrate/agent.py`) is given a system prompt describing ADO→GHA conversion rules and a small set of tools:

- `list_ado_pipelines` / `list_ado_releases` — query the ADO REST API
- `fetch_ado_pipeline_definition` / `fetch_ado_release_definition` — pull the full JSON for one definition
- `read_local_ado_export` — fallback for offline testing
- `write_gha_workflow` — writes the YAML the agent generates to `output/.github/workflows/`

The agent loops via `client.beta.messages.tool_runner()` until it has produced and written the workflow file.

## Project layout

```
ado_migrate/
  cli.py            # Click entry point
  agent.py          # Claude agent loop
  tools/
    ado_client.py   # ADO REST + file-fallback tools
    gha_writer.py   # writes generated YAML to output/
prompts/
  system.md         # conversion rules + agent instructions
examples/           # sample exported ADO definitions for offline testing
output/             # generated GHA workflows go here
tests/
```
