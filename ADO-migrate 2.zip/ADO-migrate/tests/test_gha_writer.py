"""Smoke test for the GHA writer — verifies YAML validation and slugging."""

import pytest

from ado_migrate.tools import gha_writer


def test_writes_valid_yaml(tmp_path, monkeypatch):
    monkeypatch.setattr(gha_writer, "OUTPUT_DIR", tmp_path)
    yaml_str = "name: Test\non:\n  push: {}\njobs:\n  build:\n    runs-on: ubuntu-latest\n    steps:\n      - run: echo hi\n"
    written = gha_writer.write_workflow("Test Workflow", yaml_str)
    assert written.endswith("test-workflow.yml")
    assert (tmp_path / "test-workflow.yml").read_text() == yaml_str


def test_rejects_invalid_yaml(tmp_path, monkeypatch):
    monkeypatch.setattr(gha_writer, "OUTPUT_DIR", tmp_path)
    with pytest.raises(ValueError):
        gha_writer.write_workflow("Bad", "name: test\n  bad: [unclosed")
