"""Writes generated GitHub Actions workflow YAML to the local output directory."""

from __future__ import annotations

import re
from pathlib import Path

import yaml

OUTPUT_DIR = Path(__file__).resolve().parents[2] / "output" / ".github" / "workflows"


def _slug(name: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9_-]+", "-", name).strip("-").lower()
    return s or "workflow"


def write_workflow(name: str, yaml_content: str) -> str:
    """Validate the YAML parses, then write it to output/.github/workflows/<slug>.yml.

    Returns the absolute path written.
    """
    try:
        yaml.safe_load(yaml_content)
    except yaml.YAMLError as e:
        raise ValueError(f"Generated content is not valid YAML: {e}") from e

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    path = OUTPUT_DIR / f"{_slug(name)}.yml"
    path.write_text(yaml_content)
    return str(path)
